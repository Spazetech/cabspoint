<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Postcode_model extends CI_Model
{
	
	function saverecords($data)
	{
        $this->db->insert('postcode',$data);
        return true;
	}
}