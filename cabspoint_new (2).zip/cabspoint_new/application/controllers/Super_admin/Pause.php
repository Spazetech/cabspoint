<?php 
class Pause extends CI_Controller 
{
	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	
	/*load database libray manually*/
	$this->load->database();
	
	/*load Model*/
	$this->load->model('Pause_model');
	}
      
	/*Insert*/
	public function index()
	{
		/*load registration view form*/
		$this->load->view('super_admin/pause');
	
		/*Check submit button */
		if($this->input->post('save'))
		{
		    $data['length_of_pause']=$this->input->post('length_of_pause');
			$data['apply_to']=$this->input->post('apply_to');
		
			$response=$this->Pause_model->saverecords($data);
			if($response==true){
				echo "<script>alert('Immediate Freeze Saved Successfully ')</script>";
			}
			else{
					echo "Insert error !";
			}
		}
	}
	public function future()
	{
		/*load registration view form*/
		$this->load->view('super_admin/pause');
	
		/*Check submit button */
		if($this->input->post('submit'))
		{
		    $data1['starting_on']=$this->input->post('starting_on');
            $data1['ending_on']=$this->input->post('ending_on');
			$data1['length_of_pause']=$this->input->post('length_of_pause');
		// print_r($data);
			$response=$this->Pause_model->saverecord($data1);
			if($response==true){
			        echo "<script>alert('Future Freeze Saved Successfully ')</script>";
			}
			else{
					echo "Insert error !";
			}
		}
	}
	public function displaydata()
	{
		// $data=User::all();
		$this->load->model('Pause_model');
		$data['result']=$this->Pause_model->display_records();
		$this->load->view('display_records',$data);
	}
	public function delete($id) {
        $this->load->model('Pause_model');
        $this->Pause_model->delete_data($id);
        redirect('Pause/index');
    }

	
}