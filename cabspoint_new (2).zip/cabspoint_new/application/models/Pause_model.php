<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pause_model extends CI_Model
{
	
	function saverecords($data)
	{
        $this->db->insert('immediate_pause',$data);
        return true;
	}
	function saverecord($data1)
	{
        $this->db->insert('future_pause',$data1);
        
        return true;
	}
	function display_records()
	{
	  $query=$this->db->get("immediate_pause");
	  return $query->result();
	}
	public function delete_data($id) {
        $this->db->where('id', $id);
        $this->db->delete('immediate_pause');
    }  
	
}