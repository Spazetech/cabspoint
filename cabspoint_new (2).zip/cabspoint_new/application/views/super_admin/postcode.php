
<!DOCTYPE html>
<html lang="en">

<?php include('includes/header.php'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<body>
<style>

body{
	background-color:#f5f5f5;
}

form{
	margin: 50px auto;
}

.form-row{
	margin-top: 10px;
}

body {
  /* Set "my-sec-counter" to 0 */
  counter-reset: my-sec-counter;
}

h5::before {
  /* Increment "my-sec-counter" by 1 */
  counter-increment: my-sec-counter;
  content: "E "  counter(my-sec-counter) ". ";
}

</style>
<script>
$(document).ready(function(){
  $(".Ezone").click(function(){
    $("#description").toggle();
  });
});
</script>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include('includes/navbar.php'); ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include('includes/sidebar.php'); ?>
      <!-- partial -->
      <div class="main-panel">
     <!----main  content---->
     <?php
use SimpleExcel\SimpleExcel;

if(isset($_POST['import'])){
    if(move_uploaded_file($_FILES['excel_file']['tmp_name'],$_FILES['excel_file']['name'])){
        require_once('SimpleExcel/SimpleExcel.php'); 
        
        $excel = new SimpleExcel('csv');                  
        
        $excel->parser->loadFile($_FILES['excel_file']['name']);           
        
        $foo = $excel->parser->getField(); 
       $db = mysqli_connect('localhost','root','','cabspoint_db');

        
        foreach($foo as $row){
            $zone_id = $row[0];
            $Heathrow = $row[1];
            $Gatwick = $row[2];
            $Stansted = $row[3];
            $Luton = $row[4];
            $City_Airport = $row[5];
            $Southend = $row[6];
            
            // Check if the data already exists in the database
            $query = "SELECT * FROM postcode WHERE zone_id='$zone_id'";
            $result = mysqli_query($db, $query);
            
            if(mysqli_num_rows($result) == 0){
                $query = "INSERT INTO postcode(zone_id,Heathrow,Gatwick,Stansted,Luton,City_Airport,Southend) VALUES ('$zone_id','$Heathrow','$Gatwick','$Stansted','$Luton','$City_Airport','$Southend')";
                //   print_r($query);
                //   die();
                mysqli_query($db,$query);

            }
            else{
                echo "Skipping duplicate data for zone_id: $zone_id<br>";
            }
        }

        echo "<script> alert('Post Code Added Successfully');;</script>";
   
    }else{
        echo "Error uploading file";
    }
}
?>

   <div class="table-responsive" style=" margin-top: 50px;
    margin-left: 50px; overflow-x:hidden;">
        <div class="form-control file-upload" style="    width: 454px;
    margin-left: 90px;
    border-radius: 10px;">
           <h6>Fixed price for Post Code to Post Code</h6><br>
           <h6>Upload your Excel Sheet </h6><br><br>
           <form method="post"  enctype="multipart/form-data">
            <input type="file" name="excel_file" accept=".csv">
          <input type="submit" name="import" value="Import">
       </form>
         </div><br><br>
		<div class="drgLine"></div>
        <form method="post"  action="<?= base_url() ?>Super_admin/Postcode/index" >
        <?php
        $conn = new mysqli("localhost", "root", "" ,"cabspoint_db");
	if(isset($_POST['update'])){
      
		$id=$_POST['id'];
		$Heathrow=$_POST['Heathrow'];
		$Gatwick=$_POST['Gatwick'];
        $Stansted=$_POST['Stansted'];
        $Luton=$_POST['Luton'];
        $City_Airport=$_POST['City_Airport'];
        $Southend=$_POST['Southend'];
		
			$s = "UPDATE  postcode SET Southend='$Southend', Gatwick='$Gatwick', Stansted='$Stansted', Luton='$Luton', City_Airport='$City_Airport', Southend='$Southend' WHERE id=$id"; 
		// print_r($s);
        // die();
		
		if($conn->query($s)===TRUE){
		echo "<script>alert('update Successfully!'); </script>";
		}else{
		echo $conn->error;
		}
	}
		

         ?>
         <div class="form-row">
                <div class="col">
                <a href="postcode.php?id=<?php echo $s ['id']; ?>"><button class="btn"><i class="fa fa-bars"></i> Update Post Code</button></a>
                </div>
            </div>
      
            <table class="table">
                <thead>
                <tr>
                    
                <th class="thd_th thd_th1 unselectable" ><div class="hdTbBx" tag="1">Zone</div><div class="dgSel dgSel1" tag="1" width="161"></div></th>
  	     	   <th class="thd_th thd_th1 unselectable" ><div class="hdTbBx" tag="1">Heathrow</div><div class="dgSel dgSel1" tag="1" width="161"></div></th>
	   		   	<th class="thd_th thd_th5 unselectable" ><div class="hdTbBx" tag="5" >Gatwick </div><div class="dgSel dgSel5" tag="5" width="192"></div></th>
	   		   	<th class="thd_th thd_th7 unselectable" ><div class="hdTbBx" tag="7" >Stansted</div><div class="dgSel dgSel7" tag="7" width="256"></div></th>
	   		   	<th class="thd_th thd_th8 unselectable" ><div class="hdTbBx" tag="8" >Luton</div><div class="dgSel dgSel8" tag="8" width="393"></div></th>
	   		   	<th class="thd_th thd_th9 unselectable" ><div class="hdTbBx" tag="9" >City Airport </div><div class="dgSel dgSel9" tag="9" width="374"></div></th>
                <th class="thd_th thd_th9 unselectable"   ><div class="hdTbBx" tag="9" >Southend </div><div class="dgSel dgSel9" tag="9" width="374"></div></th>
                </tr>
                </thead>
                <tbody>
                <?php
                     $db = mysqli_connect('localhost','root','','cabspoint_db');

                                $query="SELECT * FROM postcode";
                                $row = mysqli_query($db,$query);

                                while($data = mysqli_fetch_array($row)){
                                ?>
            
                <tr>
                     <input type="hidden" name="id" value="<?php echo $data['id']; ?>" />
                    <td>  <label for="html" class="form-control" name="zone_id"  readonly style="background: whitesmoke;width: 20px;border: 2px solid whitesmoke;">
                     <?=$data['zone_id']?></label></td>
                    <td><input type="text" class="form-control" name="Heathrow" placeholder=" " value="<?=$data['Heathrow']?>" required></td>
                    <td> <input type="text" class="form-control" name="Gatwick" placeholder="" value="<?=$data['Gatwick']?>" required></td>
                    <td> <input type="text" class="form-control" name="Stansted" placeholder="" value="<?=$data['Stansted']?>" required></td>
                    <td>  <input type="text" class="form-control" name="Luton" placeholder="" value="<?=$data['Luton']?>" required> </td>
                    <td>  <input type="text" class="form-control" name="City_Airport" placeholder=""  value="<?=$data['City_Airport']?>" required></td>
                    <td>  <input type="text" class="form-control" name="Southend" placeholder="" value="<?=$data['Southend']?>" required></td>
                </tr>
                <?php
                   }
                  ?>
               
                </tbody>
            </table>
        </form>
   </div>
     <!---End Content--->
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <?php include('includes/footer.php'); ?>
        
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
        <script>
            $(document).ready(function () {
                var i = 1;
                $('#add').click(function () {
                    i++;
                    $('#dynamic_field').append('<div class="form-row" id="row' + i + '"> <h5 name="zone_id" style="margin-top: 14px;"></h5><div class="col"><input type="text" class="form-control" name="Heathrow_T2[]"> </div> <div class="col"><input type="text" class="form-control" name="Heathrow_T3[]"> </div> <div class="col"><input type="text" class="form-control" name="	Heathrow_T4[]"> </div> <div class="col"><input type="text" class="form-control" name="	Heathrow_T5[]"> </div> <div class="col"><input type="text" class="form-control" name="Gatwick_South[]"> </div> <div class="col"><input type="text" class="form-control" name="Gatwick_North[]"> </div>  <div class="col"><input type="text" class="form-control" name="Stansted[]"> </div><div class="col"> <input type="text" class="form-control" name="Luton[]"> </div> <div class="col"> <input type="text" class="form-control" name="City_Airport[]"> </div> <div class="col"> <input type="text" class="form-control" name="Southend[]"> </div> <div class="col">  </div> </div>');
                });
                $(document).on('click', '.btn_remove', function () {
                    var button_id = $(this).attr("id");

                    $('#row' + button_id + '').remove();
                });




  

            });
        </script>
  
</body>

</html>