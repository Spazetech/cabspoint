
<?php 

class Postcode extends CI_Controller 
{
	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	
	/*load database libray manually*/
	$this->load->database();
	
	/*load Model*/
	$this->load->model('Postcode_model');
	}
        /*Insert*/
	public function index()
	{
		/*load registration view form*/
		$this->load->view('super_admin/postcode');
	
		/*Check submit button */
		// if($this->input->post('save'))
		// {
		// 	$data['zone']=$this->input->post('zone');
		//     $data['Heathrow_T2']=$this->input->post('Heathrow_T2');
		// 	$data['Heathrow_T3']=$this->input->post('Heathrow_T3');
		// 	$data['Heathrow_T4']=$this->input->post('Heathrow_T4');
		// 	$data['Heathrow_T5']=$this->input->post('Heathrow_T5');
		// 	$data['Gatwick_South']=$this->input->post('Gatwick_South');
		// 	$data['Gatwick_North']=$this->input->post('Gatwick_North');
		// 	$data['Stansted']=$this->input->post('Stansted');
		// 	$data['Luton']=$this->input->post('Luton');
		// 	$data['City_Airport']=$this->input->post('City_Airport');
		// 	$data['Southend']=$this->input->post('Southend');

		// 	$response=$this->Postcode_model->saverecords($data);
		// 	if($response==true){
		// 	        echo "Records Saved Successfully";
		// 	}
		// 	else{
		// 			echo "Insert error !";
		// 	}
		// }
		
	}
	
}