<?php 
class Crud extends CI_Controller 
{
	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	
	/*load database libray manually*/
	$this->load->database();
	
	/*load Model*/
	$this->load->model('Crud_model');
	}
      
	/*Insert*/
	public function index()
	{
		/*load registration view form*/
		$this->load->view('super_admin/pause');
	
		/*Check submit button */
		if($this->input->post('save'))
		{
		    $data['starting_on']=$this->input->post('starting_on');
            $data['ending_on']=$this->input->post('ending_on');
			$data['apply_to']=$this->input->post('apply_to');
		print_r($data);
			$response=$this->Crud_model->saverecords($data);
			if($response==true){
			        echo "Records Saved Successfully";
			}
			else{
					echo "Insert error !";
			}
		}
	}
	
}