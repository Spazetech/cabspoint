<?php
class Crud_model extends CI_Model 
{
  /*View*/
  function saverecords($data)
	{
        $this->db->insert('future_pause',$data);
        
        return true;
	}

	
}