
<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Offerjobs extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
              $this->load->helper(array("file", "url","document_upload_helper"));
              $this->load->library(array("session", "encryption","form_validation"));
              $this->load->model(array("formvalidation_model","database_model"));
              $config = Array(
                  'protocol' => 'sendmail',
                  'mailtype' => 'html',
                  'charset' => 'utf-8',
                  'wordwrap' => TRUE
              );
              $this->load->library('email', $config);
              $this->load->database();
              if (!$this->session->userdata('login_status'))
              { 
                  redirect('super_admin');
              }

    }
	public function index()
	{
		$this->load->view('super_admin/offer-jobs');
	}

  public function addeditofferjobs($id=false)
  {
    $data['title'] = "Add Offer Jobs";
    $data['button'] = "Submit";
    $data['car_type'] = $this->database_model->getdata('tbl_car_type','L');
    $payment_type_array = array("status"=>'1');
    $data['payment_type'] = $this->database_model->getdata('table_payment_type','L',$payment_type_array);
    
    $this->load->view('super_admin/ajax/add-edit-offer-jobs',$data);
  }

/*through Ajax  insertion */

public function demo_create()
{

    // Data for tbl_offer_customer table
    $offer_id = $this->input->post('offer_id');
// print_r($offer_id);
// die();
    $phone = $this->input->post('phone');
    $email = $this->input->post('email');
    $passenger_count = $this->input->post('passenger_count');
    $luggages_count = $this->input->post('luggages_count');
    $flight_name =$this->input->post('flight_name');
    $city_of_arrival= $this->input->post('city_of_arrival');
    $meet_after_time = $this->input->post('meet_after_time');
    $booker_agency = $this-> input->post('booker_agency');

    $customer_data = array(
      // 'offer_id'=> $job_reference,
        'phone' => $phone,
        'email' => $email,
        'passenger_count' => $passenger_count,
        'luggages_count' => $luggages_count,
        'flight_name'  =>  $flight_name,
        'city_of_arrival' => $city_of_arrival,
        'meet_after_time'  => $meet_after_time,
        'booker_agency'   => $booker_agency,
    );
 

    // Data for tbl_offer_job table
    $job_reference = $this->input->post('job_reference');
    $pickup_code = $this->input->post('pickup_code');
    $pickup_address = $this->input->post('pickup_address');
    $dropoff_code = $this->input->post('dropoff_code');
    $dropoff_address = $this->input->post('dropoff_address');
    $journey_time = $this->input->post('journey_time');
    $child_seat = $this->input->post('child_seat');
    $car_type = $this->input->post('car_type');
    $payment_type = $this->input->post('payment_type');
    $original_price = $this->input->post('original_price');
    $byit_now_price = $this->input->post('byit_now_price');
    $notes = $this->input->post('notes');
    $bid_open_time = $this->input->post('bid_open_time');
    $job_data = array(
        'job_reference' => $job_reference,
        'pickup_code' => $pickup_code,
        'pickup_address' => $pickup_address,
        'dropoff_code' => $dropoff_code,
        'dropoff_address' => $dropoff_address,
        'journey_time' => $journey_time,
        'child_seat' => $child_seat,
        'car_type' => $car_type,
        'payment_type' => $payment_type,
        'original_price' => $original_price,
        'byit_now_price' => $byit_now_price,
        'notes' => $notes,
        'bid_open_time' => $bid_open_time,
    );

    $this->load->model('ajax_model');
    $insert = $this->ajax_model->createData($job_data, $customer_data);
    echo json_encode($insert);
}

}
