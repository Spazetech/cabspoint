<!DOCTYPE html>
<html lang="en">
<?php include('includes/header.php'); ?>

<link rel="stylesheet" href="<?php echo base_url($assets);?>..\superadmin\css\pause.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<style>
/* SECOND CHECK BOX */
.selectBox1 {
position: relative;
}

.selectBox1 select {
width: 100%;
font-weight: bold;
}

.overSelect1 {
position: absolute;
left: 0;
right: 0;
top: 0;
bottom: 0;
}

#checkboxes1 {
display: none;
border: 1px #dadada solid;
}

#checkboxes1 label {
display: block;
}

#checkboxes1 label:hover {
background-color: #1e90ff;
}
.selectBox {
position: relative;
}

.selectBox select {
width: 100%;
font-weight: bold;
}

.overSelect {
position: absolute;
left: 0;
right: 0;
top: 0;
bottom: 0;
}

#checkboxes {
display: none;
border: 1px #dadada solid;
}

#checkboxes label {
display: block;
}

#checkboxes label:hover {
background-color: #1e90ff;
}
.type{
    border: 1px solid #652e8f4f !important;
width: 113px;
padding-top: 10px;
border-radius: 5px;
}
.immediate{
border: 2px solid #cfbedc;
padding: 20px;
border-radius: 5px;
}

.formfield{
display: inline-flex;
align-items: center;
justify-content: space-between;
gap: 1rem;
height: 44px;
width: 482px;
background-color: #fafafa;
border: 1px solid #ebebeb;
border-radius: 4px;
padding: 4px 12px;
}

label{
color: #666;
}

input{
background: none;
border: none;
outline: none;
font-size: 1rem;
accent-color: red;
}

</style>
<body>

  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include('includes/navbar.php'); ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include('includes/sidebar.php'); ?>
      <!-- partial -->
      <div class="main-panel">
     <!----main  content---->
     <div class="container mt-5">
        <div class="title">
          <h3>Freeze Availability</h3>
        </div>
            <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link active" href="#">
            Petrol, Diesel & Hybrid</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="#">Help</a>
                </li>
                
               
            </ul>
        <div class="row" style="margin-top:20px;">
            <div class="col-lg-12 col-md-12">
                <ul class="nav nav-pills" role="tablist" style=" background-color: #652e8f4f !important;">
                    <!--
                        color-classes: "nav-pills-primary", "nav-pills-info", "nav-pills-success", "nav-pills-warning","nav-pills-danger"
                    -->
                    <li class="nav-item">
                        <a class="nav-link" href="#dashboard-1" role="tab" data-toggle="tab">
                        Immediate Freeze
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#schedule-1" role="tab" data-toggle="tab">
                        Future  Freeze
                        </a>
                    </li>
                   
                </ul>
                <div class="tab-content tab-space">
                    <div class="tab-pane active" id="dashboard-1">
                   you can set your pickup unavailability by yourself 
                      <br><br>
                    <div class="jumbotron">
                       <div class="row">
                        <div class="col-md-6 col-sm-6 col-lg-6">
                           <h5 class="mb-4"> Immediate Freeze</h5>
                           <form class="immediate"  method="post" action="<?= base_url() ?>Super_admin/Pause/index">
                             <div class="d-flex flex-column">
                                     <div class="d-flex flex-row">
                                     
                                      <div class="" >
                                   <div class="apply" >
                                      Length of pause<br> <br>  <input type="time" class="form-control" place="select date and time" name="length_of_pause">
                                  
                                        </div><br>

                                          </span>
                                         </h5>
                                        </div>
                                    </div>
                                      <div class="invalid-feedback d-block" id="err_immediate_pause_length_1_3"></div>
                                </div>
                                <div class="apply" >
                            
                                <div class="multiselect" name="apply_to" style=" margin-top: 2px;">
                                <label for="">Apply to</label><br><br>
                                <input type="checkbox" name="all" id="checkall"/>&nbsp;&nbsp;Select All</br><br>
                                <input type="checkbox" class="cb-element" name="apply_to" value="Saloon" /> &nbsp;&nbsp;Saloon </br><br>
                                <input type="checkbox" class="cb-element"  name="apply_to"  value="Estate"/>&nbsp;&nbsp; Estate</br><br>
                                <input type="checkbox" class="cb-element"  name="apply_to" value="MPV Small" /> &nbsp;&nbsp;MPV Small<br><br>
                                <input type="checkbox" class="cb-element"  name="apply_to"  value="MPV Small"/> &nbsp;&nbsp;MPV Small<br><br>
                                <input type="checkbox" class="cb-element"  name="apply_to" value="Mini Van"/> &nbsp;&nbsp;Mini Van<br><br>
                                <input type="checkbox" class="cb-element" name="apply_to"  value="Executive Saloon" /> &nbsp;&nbsp;Executive Saloon<br><br>
                                <input type="checkbox" class="cb-element" name="apply_to"  value="Executive Van"/> &nbsp;&nbsp;Executive Van<br><br>
                              </div>
                               </div><br>
                              <input type="submit"  name="save" class="btn btn-primary" style="color: #fff; background-color: #9c27b0;" value="Confirm Immediate Pause">
                            </form>
                            </div>
                          

                            <div class="col-md-6 col-sm-6 col-lg-6">
                            <h5 class="mb-4">Recent Freeze</h5>
                                <table class="table table-bordered"  >
                                      <?php
                                      $url='localhost';
                                      $username='root';
                                      $password='';
                                      $conn=mysqli_connect($url,$username,$password,"cabspoint_db");
                                      if(!$conn){
                                      die('Could not Connect My Sql:' .mysql_error());
                                      }
                                      $result = mysqli_query($conn,"SELECT * FROM immediate_pause");
                                      ?>
                                    <thead>
                                    <tr>
                                        <th>Length of pause</th>
                                        <th>Apply to</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <?php
                                    $i=0;
                                    while($row = mysqli_fetch_array($result)) {
                                    ?>
                                    <tr>
                                     <td style="display:none;"><?php echo $row['id']; ?></td> <!-- access "id" property on array -->
                                        <td><?php echo $row["length_of_pause"]; ?></td>
                                        <td><?php echo $row["apply_to"]; ?></td>
                                        <td>  <a href="#"><i class="fa fa-edit" ></i></a>&nbsp;&nbsp;
                                       <a href="<?php echo base_url('Pause/delete/'.$row['id']); ?>"><i class="fa fa-trash"></i></a> <!-- access "id" property on array -->
                                        </td>
                                    </tr>
                                    <?php
                                    $i++;
                                    }
                                    ?>
                                  <tbody>
                                <tr>
                                
                                
                              
                            </tr>
                            </tbody>
                        </table>
                           </div>
                    
                        </div>
                      </div>
                      
                    </div>

                    <div class="tab-pane" id="schedule-1">
                    you can set your pickup unavailability by yourself
                      
                      <br><br>
                    <div class="jumbotron">
                       <div class="row">
                        <div class="col-md-6 col-sm-6 col-lg-6">
                           <h5 class="mb-4">Future Freeze</h5>
                           <form class="immediate" method="post" enctype="multipart/form-data"  action="<?= base_url() ?>Super_admin/Pause/future">
                                    <div class="formfield">
                                    <label>Start Date:</label>
                                    <input type="datetime-local" value="2023-01-01T00:00" name="starting_on"  />
                                </div><br>

                                <div class="formfield" style=" margin-top: 15px;">
                                    <label>End Date:</label>
                                    <input type="datetime-local" value="2023-01-01T00:00" max="2023-02-10T00:00" name="ending_on" />
                                </div><br>
                                
                                <div class="apply" style=" margin-top: 18px;">
                                <label for="">Apply to</label><br><br>
                                <div class="multiselect1">
                                <input type="checkbox" name="all" id="checkall"/>&nbsp;&nbsp;Select All</br><br>
                                <input type="checkbox" class="cb-element" name="length_of_pause" value="Saloon" /> &nbsp;&nbsp;Saloon </br><br>
                                <input type="checkbox" class="cb-element"  name="length_of_pause"  value="Estate"/>&nbsp;&nbsp; Estate</br><br>
                                <input type="checkbox" class="cb-element"  name="length_of_pause" value="MPV Small" /> &nbsp;&nbsp;MPV Small<br><br>
                                <input type="checkbox" class="cb-element"  name="length_of_pause"  value="MPV Small"/> &nbsp;&nbsp;MPV Small<br><br>
                                <input type="checkbox" class="cb-element"  name="length_of_pause" value="Mini Van"/> &nbsp;&nbsp;Mini Van<br><br>
                                <input type="checkbox" class="cb-element" name="length_of_pause"  value="Executive Saloon" /> &nbsp;&nbsp;Executive Saloon<br><br>
                                <input type="checkbox" class="cb-element" name="length_of_pause"  value="Executive Van"/> &nbsp;&nbsp;Executive Van<br><br>
                                </div>
                              </div><br>
                              <input type="submit"  name="submit" class="btn btn-primary" style="color: #fff; background-color: #9c27b0;" value="Confirm Future Pause">
                              </form>
                            </div>
                            
                            <div class="col-md-6 col-sm-6 col-lg-6">
                            <h5 class="mb-4">Future Freeze</h5>
                            <table class="table table-bordered"  >
                            <thead>
                            <tr>
                                <th>Apply to</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                             
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                           
                                <td>1-4 passenger</td>
                                <td>25/04/2023 8:00</td>
                                <td>25/04/2023 8:00</td>
                               
                                <td>
                                <a href="#"><i class="fa fa-edit" ></i></a>
                                <a href="#"><i class="fa fa-trash"></i></a>
                            </td>
                            </tr>
                           <tr>
                            <td>1-4 passenger</td>
                            <td>25/04/2023 8:00</td>
                                <td>25/04/2023 8:00</td>
                               
                                <td>
                                <a href="#"><i class="fa fa-edit" ></i></a>
                                <a href="#"><i class="fa fa-trash"></i></a>
                            </td>
                            </tr>
                            <tr>
                            <td>1-4 passenger</td>
                            <td>25/04/2023 8:00</td>
                                <td>25/04/2023 8:00</td>
                               
                                <td>
                                <a href="#"><i class="fa fa-edit" data-toggle="modal" data-target="#myModal1" ></i></a>
                                <a href="#"><i class="fa fa-trash"></i></a>
                                <div class="modal fade" id="myModal1" role="dialog">
                                <div class="modal-dialog  modal-lg">
                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-body">
                                    <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>Apply to</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                             
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                           
                                <td>1-4 passenger</td>
                                <td>25/04/2023 8:00</td>
                                <td>25/04/2023 8:00</td>
                               
                                <td>
                                <button type="submit" class="form-control" value="submit">Submit</button>
                            </td>
                            </tr>
                            </tbody>
                              </table>
                                    </div>
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                                
                                </div>
                            </td>
                            </tr>
                            </tbody>
                          </table>
                           </div>
                        
                        </div>
                    </div>
                  
                </div>
            </div>
            
            <div class="col-lg-6 col-md-12">
              
            </div>
        </div>
       
    </div>
     <!---End Content--->
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <?php include('includes/footer.php'); ?>
        
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <script>
   var expanded = false;

function showCheckboxes() {
  var checkboxes = document.getElementById("checkboxes");
  if (!expanded) {
    checkboxes.style.display = "block";
    expanded = true;
  } else {
    checkboxes.style.display = "none";
    expanded = false;
  }
}
</script>
<script>
   var expanded = false;

function showCheckboxes1() {
  var checkboxes1 = document.getElementById("checkboxes1");
  if (!expanded) {
    checkboxes1.style.display = "block";
    expanded = true;
  } else {
    checkboxes1.style.display = "none";
    expanded = false;
  }
}

$('#checkall').change(function () {
    $('.cb-element').prop('checked',this.checked);
});

$('.cb-element').change(function () {
 if ($('.cb-element:checked').length == $('.cb-element').length){
  $('#checkall').prop('checked',true);
 }
 else {
  $('#checkall').prop('checked',false);
 }
});

 </script>
</body>

</html>