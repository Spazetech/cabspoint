
<head>
<?php $assets = "assets/superadmin/";?>
  <!-- Required meta tags --> 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Cabspoint Admin</title>
  <!-- base:css -->
  <link rel="stylesheet" href="<?php echo base_url($assets);?>vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url($assets);?>vendors/feather/feather.css">
  <link rel="stylesheet" href="<?php echo base_url($assets);?>vendors/base/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url($assets);?>vendors/flag-icon-css/css/flag-icon.min.css"/>
  <link rel="stylesheet" href="<?php echo base_url($assets);?>vendors/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo base_url($assets);?>vendors/jquery-bar-rating/fontawesome-stars-o.css">
  <link rel="stylesheet" href="<?php echo base_url($assets);?>vendors/jquery-bar-rating/fontawesome-stars.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo base_url($assets);?>css/style.css">
  <link rel="stylesheet" href="<?php echo base_url($assets);?>css/sweetalert.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo base_url($assets);?>images/favicon.png" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url($assets);?>css/jquery.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url($assets);?>css/multiselect.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">

</head>