<?php 

class Ajax_model extends CI_Model
{
	// public function createData($data)
	// {
	// 	$this->db->select('*');
	// 	$this->db->from('tbl_offer_job');
	// 	$this->db->join('tbl_offer_customer', 'tbl_offer_customer.id = tbl_offer_job.id');
	// 	$query = $this->db->insert('tbl_offer_job','tbl_offer_customer',$data);
	// 	// $query = $this->db->get();
	//     //  return $query->result();

	// 	return $query;
	// }
	public function createData($job_data, $customer_data)
{
    // Start transaction
    $this->db->trans_start();
    // print_r($customer_data);die;
    // Insert data into tbl_offer_customer table
    $this->db->insert('tbl_offer_customer', $customer_data);
	
    $id = $this->db->insert_id();


    // Insert data into tbl_offer_job table
    // $job_data['customer_id'] = $customer_id;
    $this->db->insert('tbl_offer_job', $job_data);
    $job_id = $this->db->insert_id();

    // Commit transaction
    $this->db->trans_complete();

    // Check transaction status
    if ($this->db->trans_status() === false) {
        return false;
    } else {
        return $job_id;
    }
}
}